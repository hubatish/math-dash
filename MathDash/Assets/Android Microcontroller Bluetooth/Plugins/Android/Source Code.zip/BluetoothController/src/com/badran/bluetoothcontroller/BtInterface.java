package com.badran.bluetoothcontroller;
/* Android PlugIn for Unity Game Engine
 * By Tech Tweaking
 */

import android.bluetooth.BluetoothAdapter;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Set;
import java.util.UUID;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;



public class BtInterface extends Thread {
	
 
	
	class MessagesThread {
		public volatile ArrayList<Object []> outMessages = new ArrayList<Object []>();
		
		public volatile char charMessage = (char)0;
		public volatile String stringMessage = "";
		public volatile byte[] bytesMessage  = new byte []{};
	  }
	private final MessagesThread messagesThread = new MessagesThread();
	
	private BluetoothDevice device = null;
	private BluetoothSocket socket = null;
	private BluetoothAdapter mBluetoothAdapter = null;
	private InputStream receiveStream = null;
	private BufferedReader receiveReader = null;
	private OutputStream sendStream = null;	
	private BufferedInputStream receiveBuffer = null;
	private PrintWriter writer = null;
	private BufferedOutputStream outBufferStream = null;
	private BtReceiver RECEIVER;
	private BtSender SENDER;
		
	private boolean sending = true;
	private boolean issending = false;
	private boolean isConnected = false;
	
	private boolean bufferDataAvailable = false;
	private boolean dataAvailable = false;
	
	private byte [] buffer = {};
	private byte [] tempBuffer = {};
	private String stringData = "";
	
	
	class ControlThread {
	    public volatile boolean MODE = true;
	    public volatile boolean MODE2 = false;
	    public volatile boolean startListen = true;
	    public volatile boolean listening = false;
	    public volatile byte stopByte ;
	    public volatile int length = 0;
	  }
	
	private final ControlThread control = new ControlThread();
	public BtInterface(BluetoothAdapter tempBluetoothAdapter) {
		this.mBluetoothAdapter =tempBluetoothAdapter;
	}
	
	public void run() {
		
		Set<BluetoothDevice> setpairedDevices = mBluetoothAdapter.getBondedDevices();
    	BluetoothDevice[] pairedDevices = (BluetoothDevice[]) setpairedDevices.toArray(new BluetoothDevice[setpairedDevices.size()]);
		boolean foundModule = false;
		
		for(int i=0;i<pairedDevices.length;i++) {
			if(this.isInterrupted()) return;
			boolean temp ;
			if(Bridge.mac)
				temp = pairedDevices[i].getAddress().equals(Bridge.ModuleMac);
			else 
				temp = pairedDevices[i].getName().equals(Bridge.ModuleName);
			
				
			
				
			if(temp) {
				
				device = pairedDevices[i];
				try {
																				 
					socket = device.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));
					receiveStream = socket.getInputStream();
					receiveReader = new BufferedReader(new InputStreamReader(receiveStream));
					//receiveReader = new BufferedReader(new Reader(receiveStream));
					receiveBuffer = new BufferedInputStream(receiveStream);
					
					sendStream = socket.getOutputStream();
					outBufferStream =  new BufferedOutputStream(sendStream);
					writer = new PrintWriter(sendStream,true);
				} 
				
				catch (IOException e) {
					Bridge.controlMessage(-1);
					
					
				}
				foundModule = true;
				break;
			}
			
		}
		if(foundModule == false){
			Bridge.controlMessage(-2);
			return;
			
		}
		
		new Thread() {
			@Override public void run() {
				try {
					socket.connect();
					
					isConnected = true;
					
	                Bridge.controlMessage(1);
	                
	                RECEIVER = new BtReceiver();
	                RECEIVER.start();
	                SENDER = new BtSender();
	                SENDER.start();
					
	               
				} 
				catch (IOException e) {
					Bridge.controlMessage(-3);
					isConnected = false;
					try {
						socket.close();
					Bridge.controlMessage(-3);
		            
				} 
				catch (IOException e2) {
					Bridge.controlMessage(-3);
				}
					
				}
			}
		}.start();
		
		
	}
	public boolean isConnected() { return isConnected;}
	public boolean isSending() { return issending;}
	public boolean isListening(){return control.listening;}
	
	
	public void close() {
	
			
		control.startListen = false;
		
			if(receiveStream != null) {try{receiveStream.close();}  catch (Exception e) {}}
			if(receiveReader != null) {try{receiveReader.close();}catch (Exception e) {}}
			if(sendStream != null)  {try{sendStream.close();}catch (Exception e) {}}
			if(writer != null) { try{writer.close();}catch (Exception e) {}}
					
			try {
				socket.close();
			Bridge.controlMessage(2);
            
		} 
		catch (IOException e) {
			Bridge.controlMessage(-4);
		}finally{
			isConnected = false;}
	}
		
		
		public  void sendString(String data) {
			char [] temp3 = data.toCharArray();
			
			char [] temp4 = Arrays.copyOf(temp3, temp3.length+1);
			temp4[temp3.length] = '\n';
			
			
			
			
			messagesThread.outMessages.add(new Object [] {(Integer)1,temp4});

		}
		public  void sendChar(char data) {
			
			messagesThread.outMessages.add(new Object [] {(Integer)0,(int)data});
			
		}
		//////////////
		public  void sendBytes(byte [] data) {
			messagesThread.outMessages.add(new Object [] {(Integer)2,data});

		}
		
		public  String readLine(){
			dataAvailable = false;
			if(stringData.length() > 0){
				String tempMessage = stringData;
				stringData = "";
				return tempMessage;
				
				}else  return  "";
			
			
		}
		
		public byte [] readBuffer() { 
			dataAvailable = false;
			if (buffer == null || !bufferDataAvailable) return new byte [] {};
			bufferDataAvailable = false;
			
			return buffer;
			
		}
		public void listen (boolean start){ // read lines
			control.startListen = start;
			control.MODE2 = false;
			control.MODE = true;
				
		if(!control.listening && start){
			
			RECEIVER.start(); //read lines
				
				}
				
			

		}
		public void stopListen(){
			
			control.startListen = false;
		}
		public void stopSending(){
			
			sending = false;
		}
		
		public void startSending(){
			if(!sending && isConnected()){
				sending = true;
				SENDER.start();
				
			}
		}
		
		public boolean mode(){return control.MODE;}
		
		public void listen (boolean start, int length){// read chars
		
			
			control.startListen = start;
			control.MODE2 = false;
			control.MODE = false;
			
			
			
		if(start){
			if(length != control.length){
			tempBuffer = new byte [length];
			control.length = length;
			}
		if(!control.listening && start){
			
			
			RECEIVER.start();//read chars
				}
		
		}
		
		
		}
public void listen (boolean start, int length,byte stopByte){// read chars
		
			
			control.startListen = start;
			control.stopByte = stopByte;
			control.MODE2 = true;
			control.MODE = false;
			
		if(start){
			if(length != control.length){
			tempBuffer = new byte [length];
			control.length = length;
			}
		if(!control.listening && start){
			
			
			RECEIVER.start();//read chars
				}
		
		}
		
		
		}
		
		public boolean available(){ return dataAvailable;}
		
	public static boolean TESTINGvariable = false;
	private class BtReceiver extends Thread {
		
		
		
		/////////////////////////////////////////String dataToSend = ""; 
		@Override public  void run() {
			control.listening = true;
			int firstIndex = 0;
		 String dataToSend;
			while(socket != null && control.startListen ) {
				control.listening = true;
				if (isInterrupted()){
					control.listening = false;
					return;
				}
				
				try {
					if(receiveStream.available() > 0) {
						
						
								
						if(control.MODE){
							
						dataToSend = receiveReader.readLine();
						
						
						
							stringData = dataToSend;
							dataAvailable = true;
			                dataToSend = "";
						}
						else{
						
						if(control.MODE2){
							
							int tempByte ;
							int newLength = tempBuffer.length - firstIndex  ;
							int i = firstIndex;
							boolean notFound = true;
							for(; i< newLength;i++){
								tempByte = receiveBuffer.read();
								if(tempByte >=0){
									if(tempByte == 10) {
										firstIndex = 0;
										buffer = java.util.Arrays.copyOf(tempBuffer,i );
										bufferDataAvailable = true;
										dataAvailable = true;
										notFound = false;
										TESTINGvariable = true;
										
										  
										break;}
									tempBuffer[i] = (byte)tempByte;
								
								}
								
								else {firstIndex = i;notFound = false;break;}
								
								
							}
							if(notFound){
								firstIndex = 0;
								buffer = java.util.Arrays.copyOf(tempBuffer,tempBuffer.length);
							bufferDataAvailable = true;
							  dataAvailable = true;
							  //Arrays.fill(tempBuffer, (byte)0);
							}
							
						}else{
						
						//receiveBuffer.mark(tempBuffer.length);
							 int realLength = receiveBuffer.read(tempBuffer,firstIndex,tempBuffer.length - firstIndex - 1);
							 receiveBuffer.read(tempBuffer,0,tempBuffer.length);
							
							
							
							
								
							  buffer = java.util.Arrays.copyOf(tempBuffer,realLength);
							
							
							  bufferDataAvailable = true;
							  dataAvailable = true;
							 
							
							 }
							 
						
							 
						////////////////////}
			           
					}
				}}
				catch (IOException e) {
					control.listening = false;
					Bridge.controlMessage(-6);
				}
					
				
				
				
			} control.listening = false;
			
		}
	}
	
	private   class  BtSender extends Thread {
		public  void  run(){
			
			while(sending ) {
			while(sending && messagesThread.outMessages.size() > 0){
				issending = true;
				try{
					switch ((Integer)messagesThread.outMessages.get(0)[0]){
						case 0 : 
						outBufferStream.write((Integer)messagesThread.outMessages.get(0)[1]);
				        outBufferStream.flush();
				        break;
				        
						case 1 :writer.print((char [])messagesThread.outMessages.get(0)[1] );
								
								if(writer.checkError()) Bridge.controlMessage(-5);
						break;
						case 2 : 
						outBufferStream.write((byte [])messagesThread.outMessages.get(0)[1]);
				        outBufferStream.flush();
				        break;
				        default : break;
					}
					messagesThread.outMessages.remove(0);
					
					
				}catch (IOException e) {
					Bridge.controlMessage(-5);
					
				}
			}
			issending =false;
			
		}
		}
	}
}

/** Automatically generated file. DO NOT MODIFY */
package com.badran.bluetoothcontroller;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}